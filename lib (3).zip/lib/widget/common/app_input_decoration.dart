import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:archflow/themeData/app_color.dart';

InputDecoration appInputDecoration({
  required BuildContext context,
  required String label,
  required String hint,
  required IconData icon,
  Widget? suffixIcon,
}) {
  final isDark =
      Theme.of(context).brightness == Brightness.dark;

  final borderColor = isDark
      ? AppColors.darkDivider
      : AppColors.lightDivider;

  return InputDecoration(
    labelText: label,
    hintText: hint,

    labelStyle: GoogleFonts.lato(
      fontSize: 14,
      color: isDark
          ? AppColors.darkTextSecondary
          : AppColors.lightTextSecondary,
    ),
    hintStyle: GoogleFonts.lato(
      fontSize: 14,
      color: isDark
          ? AppColors.darkTextSecondary
          : AppColors.lightTextSecondary,
    ),

    prefixIcon: Icon(
      icon,
      color: AppColors.brandGreen,
    ),
    suffixIcon: suffixIcon,

    contentPadding: const EdgeInsets.symmetric(
      horizontal: 20,
      vertical: 18,
    ),

    /// 🔲 Default border
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
      borderSide: BorderSide(color: borderColor),
    ),

    /// 🟢 Focused border
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
      borderSide: const BorderSide(
        color: AppColors.brandGreen,
        width: 2,
      ),
    ),

    /// 🔴 Error borders
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
      borderSide: const BorderSide(
        color: AppColors.error,
      ),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
      borderSide: const BorderSide(
        color: AppColors.error,
        width: 2,
      ),
    ),
  );
}
