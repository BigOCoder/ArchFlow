import 'package:flutter/material.dart';
import 'package:archflow/themeData/app_color.dart';

class NewProjectScreen extends StatelessWidget {
  const NewProjectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('New Project'),
      ),
      body: Center(
        child: Hero(
          tag: 'new-project-hero', // 🔑 SAME TAG
          child: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(28),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.9,
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: AppColors.brandGreen,
                borderRadius: BorderRadius.circular(28),

                // 🌟 STRONGER AMBIENT GLOW
                boxShadow: [
                  BoxShadow(
                    color: AppColors.brandGreen.withOpacity(0.20),
                    blurRadius: 30,
                    spreadRadius: 4,
                    offset: const Offset(0, 0),
                  ),
                  BoxShadow(
                    color: AppColors.brandGreen.withOpacity(0.10),
                    blurRadius: 60,
                    spreadRadius: 10,
                    offset: const Offset(0, 0),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Create New Project',
                    style: theme.textTheme.headlineSmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'This is where your new workspace begins.',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
