/// User role selected during registration
enum UserRole { juniorDeveloper, student }

/// Highest education level of the user
enum EducationLevel { diploma, undergraduate, postgraduate, selfTaught }

/// Computer science background
enum CsBackground { cs, nonCs, noDegree }

/// Skill proficiency level
enum ProficiencyLevel { beginner, intermediate, advanced }

/// Preferred timeline to achieve goal
enum Timeline { oneToTwoWeeks, oneMonth, threeMonths, sixPlusMonths }

enum ArchitectureLevel { none, mvc, layered, clean, microservices }

enum DatabaseType { relational, nosql, both }

enum ComfortLevel { basicQueries, schemaDesign, indexing, transactions }

enum CodingFrequency { rarely, sometimes, daily }

enum DebuggingConfidence { low, medium, high }

/// Primary learning / career goal
enum PrimaryGoal {
  fundamentals,
  realWorldProject,
  internship,
  interview,
  startup,
  collegeProject,
}

enum SkillCategory {
  webDevelopment,
  androidDevelopment,
  backendDevelopment,
  dsa,
  other,
}

// ✨ Extension methods for beautiful display names
extension SkillCategoryExtension on SkillCategory {
  String get displayName {
    switch (this) {
      case SkillCategory.webDevelopment:
        return 'Web Development';
      case SkillCategory.androidDevelopment:
        return 'Android Development';
      case SkillCategory.backendDevelopment:
        return 'Backend Development';
      case SkillCategory.dsa:
        return 'Data Structures & Algorithms';
      case SkillCategory.other:
        return 'Other';
    }
  }
}

extension ProficiencyLevelExtension on ProficiencyLevel {
  String get displayName {
    switch (this) {
      case ProficiencyLevel.beginner:
        return 'Beginner';
      case ProficiencyLevel.intermediate:
        return 'Intermediate';
      case ProficiencyLevel.advanced:
        return 'Advanced';
    }
  }
}

extension EducationLevelExtension on EducationLevel {
  String get displayName {
    switch (this) {
      case EducationLevel.diploma:
        return 'Diploma';
      case EducationLevel.undergraduate:
        return 'Undergraduate';
      case EducationLevel.postgraduate:
        return 'Postgraduate';
      case EducationLevel.selfTaught:
        return 'Self-Taught';
    }
  }
}

extension CsBackgroundExtension on CsBackground {
  String get displayName {
    switch (this) {
      case CsBackground.cs:
        return 'Computer Science / IT';
      case CsBackground.nonCs:
        return 'Non-CS Engineering';
      case CsBackground.noDegree:
        return 'No Formal Degree';
    }
  }
}

extension TimelineExtension on Timeline {
  String get displayName {
    switch (this) {
      case Timeline.oneToTwoWeeks:
        return '1-2 Weeks';
      case Timeline.oneMonth:
        return '1 Month';
      case Timeline.threeMonths:
        return '3 Months';
      case Timeline.sixPlusMonths:
        return '6+ Months';
    }
  }
}

extension PrimaryGoalExtension on PrimaryGoal {
  String get displayName {
    switch (this) {
      case PrimaryGoal.fundamentals:
        return 'Learn Fundamentals';
      case PrimaryGoal.realWorldProject:
        return 'Build Real-World Projects';
      case PrimaryGoal.internship:
        return 'Prepare for Internship';
      case PrimaryGoal.interview:
        return 'Crack Technical Interviews';
      case PrimaryGoal.startup:
        return 'Build a Startup';
      case PrimaryGoal.collegeProject:
        return 'Complete College Project';
    }
  }
}

extension ArchitectureLevelExtension on ArchitectureLevel {
  String get displayName {
    switch (this) {
      case ArchitectureLevel.none:
        return 'None';
      case ArchitectureLevel.mvc:
        return 'MVC';
      case ArchitectureLevel.layered:
        return 'Layered Architecture';
      case ArchitectureLevel.clean:
        return 'Clean Architecture';
      case ArchitectureLevel.microservices:
        return 'Microservices';
    }
  }
}

extension DatabaseTypeExtension on DatabaseType {
  String get displayName {
    switch (this) {
      case DatabaseType.relational:
        return 'Relational (SQL)';
      case DatabaseType.nosql:
        return 'NoSQL';
      case DatabaseType.both:
        return 'Both';
    }
  }
}

extension ComfortLevelExtension on ComfortLevel {
  String get displayName {
    switch (this) {
      case ComfortLevel.basicQueries:
        return 'Basic Queries';
      case ComfortLevel.schemaDesign:
        return 'Schema Design';
      case ComfortLevel.indexing:
        return 'Indexing & Optimization';
      case ComfortLevel.transactions:
        return 'Transactions & ACID';
    }
  }
}

extension CodingFrequencyExtension on CodingFrequency {
  String get displayName {
    switch (this) {
      case CodingFrequency.rarely:
        return 'Rarely (Few times a month)';
      case CodingFrequency.sometimes:
        return 'Sometimes (Few times a week)';
      case CodingFrequency.daily:
        return 'Daily';
    }
  }
}

extension DebuggingConfidenceExtension on DebuggingConfidence {
  String get displayName {
    switch (this) {
      case DebuggingConfidence.low:
        return 'Low - Need Help Often';
      case DebuggingConfidence.medium:
        return 'Medium - Can Figure Out Most';
      case DebuggingConfidence.high:
        return 'High - Confident & Independent';
    }
  }
}
