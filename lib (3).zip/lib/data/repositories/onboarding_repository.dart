// lib/data/repositories/onboarding_repository.dart
import 'package:archflow/models/onboarding_data_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:archflow/core/network/api_client.dart';
import 'package:archflow/data/repositories/auth_repository.dart'; 

class OnboardingRepository {
  final ApiClient _apiClient;

  OnboardingRepository(this._apiClient);

  Future<void> saveOnboarding({
    required String userId,
    required OnboardingDataModel data,
  }) async {
    try {
      await _apiClient.dio.post(
        '/onboarding/$userId',
        data: data.toJson(),
      );
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<OnboardingDataModel> getOnboarding(String userId) async {
    try {
      final response = await _apiClient.dio.get('/onboarding/$userId');
      return OnboardingDataModel.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // ✅ FIXED: Better error handling
  String _handleError(DioException error) {
    if (error.response?.data != null) {
      final data = error.response!.data;
      if (data is Map && data['message'] != null) {
        return data['message'];
      }
    }
    
    if (error.response?.statusCode == 404) {
      return 'Onboarding data not found';
    }
    
    return 'Failed to process onboarding data';
  }
}

final onboardingRepositoryProvider = Provider<OnboardingRepository>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return OnboardingRepository(apiClient);
});
