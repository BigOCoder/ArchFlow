// lib/data/repositories/auth_repository.dart
import 'package:archflow/models/auth_response.dart';
import 'package:archflow/models/user_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:archflow/core/network/api_client.dart';


class AuthRepository {
  final ApiClient _apiClient;

  AuthRepository(this._apiClient);

  Future<AuthResponse> register({
    required String name,
    required String email,
    required String password,
    required bool agreedToTerms,
  }) async {
    try {
      final response = await _apiClient.dio.post(
        '/auth/register',
        data: {
          'name': name,
          'email': email,
          'password': password,
          'agreedToTerms': agreedToTerms,
        },
      );

      final authResponse = AuthResponse.fromJson(response.data);
      await _apiClient.saveToken(authResponse.token);
      return authResponse;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<AuthResponse> login({
    required String email,
    required String password,
    bool rememberMe = false,
  }) async {
    try {
      final response = await _apiClient.dio.post(
        '/auth/login',
        data: {
          'email': email,
          'password': password,
          'rememberMe': rememberMe,
        },
      );

      final authResponse = AuthResponse.fromJson(response.data);
      await _apiClient.saveToken(authResponse.token);
      return authResponse;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<AuthResponse> verifyOtp({
    required String email,
    required String otp,
  }) async {
    try {
      final response = await _apiClient.dio.post(
        '/auth/verify-otp',
        data: {
          'email': email,
          'otp': otp,
        },
      );

      final authResponse = AuthResponse.fromJson(response.data);
      await _apiClient.saveToken(authResponse.token);
      return authResponse;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<void> resendOtp(String email) async {
    try {
      await _apiClient.dio.post(
        '/auth/resend-otp',
        data: {'email': email},
      );
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<void> forgotPassword(String email) async {
    try {
      await _apiClient.dio.post(
        '/auth/forgot-password',
        data: {'email': email},
      );
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<void> resetPassword({
    required String email,
    required String otp,
    required String newPassword,
  }) async {
    try {
      await _apiClient.dio.post(
        '/auth/reset-password',
        data: {
          'email': email,
          'otp': otp,
          'newPassword': newPassword,
        },
      );
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<UserModel?> getCurrentUser() async {
    try {
      final token = await _apiClient.getToken();
      if (token == null) return null;

      final response = await _apiClient.dio.get('/auth/me');
      return UserModel.fromJson(response.data);
    } catch (e) {
      return null;
    }
  }

  Future<void> logout() async {
    try {
      await _apiClient.dio.post('/auth/logout');
    } catch (e) {
      if(kDebugMode){
        print('Logout error: $e');

      }
    } finally {
      await _apiClient.clearToken();
    }
  }

  // ✅ FIXED: Better error handling
  String _handleError(DioException error) {
    // Try to get error message from response
    if (error.response?.data != null) {
      final data = error.response!.data;
      if (data is Map && data['message'] != null) {
        return data['message'];
      }
      if (data is String) {
        return data;
      }
    }
    
    // Fallback to generic messages based on error type
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return 'Connection timeout. Please check your internet.';
      
      case DioExceptionType.badResponse:
        final statusCode = error.response?.statusCode;
        if (statusCode == 401) return 'Invalid credentials';
        if (statusCode == 400) return 'Invalid request';
        if (statusCode == 404) return 'Service not found';
        if (statusCode == 500) return 'Server error. Please try again later.';
        return 'Server error (${statusCode})';
      
      case DioExceptionType.cancel:
        return 'Request cancelled';
      
      case DioExceptionType.connectionError:
        return 'No internet connection';
      
      default:
        return 'Network error. Please try again.';
    }
  }
}

// ✅ Providers
final apiClientProvider = Provider<ApiClient>((ref) {
  return ApiClient();
});

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return AuthRepository(apiClient);
});
